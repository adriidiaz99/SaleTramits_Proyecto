package com.salesianostriana.SalesTrami;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesTramiApplicationTests {

	@Test
	void contextLoads() {
	}

}
